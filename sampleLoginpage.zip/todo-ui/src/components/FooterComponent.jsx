import React from 'react'

const FooterComponent = () => {
  return (
    <div>
      <footer className='footer'>
        <p>All Rights are valuable @ 2024</p>
      </footer>
    </div>
  )
}

export default FooterComponent