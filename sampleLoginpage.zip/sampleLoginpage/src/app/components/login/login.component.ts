import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit{
  loginForm:any = FormGroup;
  hide: boolean = true;
  rowdata : any[] = [];
  constructor(private fb: FormBuilder, private router: Router, private auth: AuthService){
  }
  ngOnInit(): void {
    this.loginForm = this.fb.group({
      username : ["", Validators.required],
      password : ["", Validators.required]
    });
  }

  onSubmit(event: any){
    console.log(this.loginForm.value);
    this.auth.postLogin(this.loginForm.value).subscribe((ele) =>{
    if(ele){
    this.rowdata = event;
    this.router.navigate(['/home']);
    }(error: any) =>{
      console.log(error);
    }
    })
  }
  // onClose(){
  //   this.router.navigate(['']);
  // }

}
