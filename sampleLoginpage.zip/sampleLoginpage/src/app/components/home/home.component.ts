import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MediaMatcher } from '@angular/cdk/layout';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
 
  mobileQuery: any ;
  isLoggedIn: boolean = false; 
  constructor(private route: Router, private authService: AuthService){
    this.authService.isLoggedIn.subscribe(loggedIn => {
      this.isLoggedIn = loggedIn;
    });
  }

  onLogin(){
    this.authService.login();
    this.route.navigate([''])
  }
  signUp(){
    this.route.navigate(['/singUp'])
  }
  onLogout(){
    this.authService.logout();
    this.route.navigate([''])
  }
}
