import { Component, EventEmitter, Output } from '@angular/core';
import { Flight } from '../../../model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-available-flights',
  templateUrl: './available-flights.component.html',
  styleUrl: './available-flights.component.css'
})
export class AvailableFlightsComponent {
flights: Flight[] = [];
@Output() messageEvent = new EventEmitter<any>();
constructor( private router: Router){

}
bookFlight(flight: Flight) {
  // Implementation for booking the flight
  this.messageEvent.emit([this.flights]);
  this.router.navigate(['/booking/:id'])
}

receiveMessage(event: any) {
  this.flights = event;  // Handle the event and update the message property
  console.log(this.flights);
}
}
