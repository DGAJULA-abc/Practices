import { HttpClient } from '@angular/common/http';
import { Component, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-flight-booking',
  templateUrl: './flight-booking.component.html',
  styleUrls: ['./flight-booking.component.css']
})
export class FlightBookingComponent {
  zoneForm: FormGroup;
  gender: string[] = ['Male', 'Female', 'Others'];
  constructor(
    private http: HttpClient,
    private route: ActivatedRoute,
    private router: Router,
    private formBuilder: FormBuilder
  ) {
    this.zoneForm = this.formBuilder.group({
      firstName: '',
      lastName: '',
      gender: ''
    });
  }

  submitdata() {
    console.log(this.zoneForm.value);
  }

  message: any[] = [];

  receiveMessage(event: any) {
    this.message = event;  // Handle the event and update the message property
    console.log(this.message);
  }
}
