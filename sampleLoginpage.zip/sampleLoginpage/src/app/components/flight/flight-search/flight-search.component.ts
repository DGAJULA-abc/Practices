import { HttpClient } from '@angular/common/http';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../../services/auth.service';
import { Flight } from '../../../model';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-flight-search',
  templateUrl: './flight-search.component.html',
  styleUrls: ['./flight-search.component.css']
})
export class FlightSearchComponent implements OnInit {
  @Output() searchDetails = new EventEmitter<any>();
  @Output() messageEvent = new EventEmitter<any>();
  zoneForm: FormGroup;
  Flights: Flight[] = [];
  flights: Flight[] = [];
  origin: string = '';
  destination: string = '';

  constructor(private formBuilder: FormBuilder, private Auth: AuthService, private router: Router) {
    this.zoneForm = this.formBuilder.group({
      origin: '',
      destination: '',
      date: '',
    });
  }

  ngOnInit() {
    this.getFlightDta();
  }

  submitdata() {
    const searchData = this.zoneForm.value;
    this.messageEvent.emit([this.zoneForm.value]);
    this.Auth.searchFlights(searchData).subscribe(
      (data: Flight[]) => {
        this.flights = data;
        this.router.navigate(['/available'])
      },
      (error) => {
        console.error('Error fetching flights:', error);
      }
    );
  }
  formData: any
  bookFlight(flight: Flight) {
    // Implementation for booking the flight
    this.messageEvent.emit([this.zoneForm.value]);
    this.router.navigate(['/booking/:id'])
  }

  getFlightDta() {
    this.Auth.getFlight().subscribe((ele: any) => {
      this.flights = ele;
    });
  }
  filteredFlights: any[] = [];
  filterFlights() {
    const { origin, destination, date } = this.zoneForm.value;
    this.filteredFlights = this.flights.filter(flight =>
      flight.origin === origin && flight.destination === destination && flight.date === date
    );
  }
}
