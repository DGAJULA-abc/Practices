import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css'
})
export class SignupComponent implements OnInit{

  signUpform: any = FormGroup;
  rowData : any[] = [];
  gender: any[] = ['Male', 'Female','Others'];
  Rolls : any[] = ['abmin','user'];
  constructor(private fb:FormBuilder,private route: Router, private Auth: AuthService){

  }
  ngOnInit(){
   this.signUpform = this.fb.group({
    firstName : ["", Validators.required],
    lastName: ["", Validators.required],
    mobile: ["", Validators.required],
    email: ["", Validators.required],
    password : ["", Validators.required],
    conformPassword : ["", Validators.required],
    gender : ["", Validators.required],
    username: ["", Validators.required],
    roles : ["", Validators.required],
   });
  }

  onSubmit(event: any){
    console.log(this.signUpform.value);
    this.Auth.getSingup(this.signUpform.value).subscribe((ele: any)=>{
     if(ele){
      this.rowData = event;
      this.route.navigate(['/home']);
     }(error: any) =>{
      console.log(error);
     }

    })
  }

  onClose(){
    this.route.navigate(['']);
  }
}
