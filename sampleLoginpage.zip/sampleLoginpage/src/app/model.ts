export class Flight {
    id?: number = 0;
    origin: string = '';
    destination: string = '';
    departureTime: string = '';
    arrivalTime: string = '';
    date: string = '';
    fare: number = 0;
}