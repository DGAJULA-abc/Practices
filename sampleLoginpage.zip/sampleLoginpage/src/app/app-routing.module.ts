import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { SignupComponent } from './components/signup/signup.component';
import { LoginComponent } from './components/login/login.component';
import { FlightSearchComponent } from './components/flight/flight-search/flight-search.component';
import { FlightBookingComponent } from './components/flight/flight-booking/flight-booking.component';
import { AvailableFlightsComponent } from './components/flight/available-flights/available-flights.component';

const routes: Routes = [
  {
    path: '',
    component: LoginComponent
  },
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'singUp',
    component: SignupComponent
  },
  { path: 'search', component: FlightSearchComponent },
  { path: 'booking/:id', component: FlightBookingComponent },
  { path: '', redirectTo: '/search', pathMatch: 'full' },
  { path: 'available', component: AvailableFlightsComponent }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
