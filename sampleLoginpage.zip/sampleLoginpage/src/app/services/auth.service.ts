import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Flight } from '../model';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private loggedIn = new BehaviorSubject<boolean>(false);
  url = 'http://localhost:8080/api/auth/signup';
 url1 = 'http://localhost:8080/api/auth/login';
 url2 = 'http://localhost:8080/search/flight'
  constructor(private http: HttpClient) { }


  getSingup(data: any){
   // let options = [data];
    return this.http.post<any>(this.url, data);
  }
  
  postLogin(data: any){
    return this.http.post<any>(this.url1, data);
  }

  getFlight(){
    return this.http.get<Flight[]>(this.url2);
  }

  get isLoggedIn() {
    return this.loggedIn.asObservable();
  }

  login() {
    this.loggedIn.next(true);
  }

  logout() {
    this.loggedIn.next(false);
  }
  // searchFlights(flightData: any): Observable<Flight[]> {
  //   let params = new HttpParams();
  //   if (flightData.origin) {
  //     params = params.set('origin', flightData.origin);
  //   }
  //   if (flightData.destination) {
  //     params = params.set('destination', flightData.destination);
  //   }
  //   // Add more conditions for other flightData properties if needed
  //   //return this.http.post<Flight[]>(`${this.url2}`, flightData, { params });
  //   return this.http.get<Flight[]>(`${this.url2}/search`, { params });
  // }

  searchFlights(searchData: any): Observable<Flight[]> {
    return this.http.post<Flight[]>(`${this.url2}/search`, searchData);
  }
}
