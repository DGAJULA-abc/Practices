import React, { Component } from 'react';
import { createEmployee, getEmployee, updateEmployee } from '../services/EmployeeService';

class EmployeeComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            id: '',
            firstName: '',
            lastName: '',
            age: '',
            college: '',
            email: '',
            userName: '',
            password: '',
            dateOfBirth: '',
            contact: '',
            roles: '',
            addresses: '',
            skills: '',
            departmentId: '',
            validationErrors: {}
        };

        // Bind event handlers
        this.handleInputChange = this.handleInputChange.bind(this);
        this.saveOrUpdateEmployee = this.saveOrUpdateEmployee.bind(this);
    }

    componentDidMount() {
        const { match } = this.props;
        if (match && match.params && match.params.id) {
            const { id } = match.params;
            getEmployee(id)
                .then(response => {
                    const { data } = response;
                    this.setState({
                        id: data.id,
                        firstName: data.firstName,
                        lastName: data.lastName,
                        age: data.age,
                        college: data.college,
                        email: data.email,
                        userName: data.userName,
                        password: data.password,
                        dateOfBirth: data.dateOfBirth,
                        contact: data.contact,
                        roles: data.roles,
                        addresses: data.addresses,
                        skills: data.skills,
                        departmentId: data.departmentId
                    });
                })
                .catch(error => {
                    console.error("Error fetching employee:", error);
                });
        }
    }

    handleInputChange(event) {
        const { name, value } = event.target;
        this.setState({ [name]: value });
    }

    validateForm() {
        const {
            firstName,
            lastName,
            age,
            college,
            email,
            userName,
            password,
            dateOfBirth,
            contact,
            roles,
            addresses,
            skills,
            departmentId
        } = this.state;

        let errors = {};
        let formIsValid = true;

        if (!firstName) {
            formIsValid = false;
            errors["firstName"] = "First Name is required.";
        }

        if (!lastName) {
            formIsValid = false;
            errors["lastName"] = "Last Name is required.";
        }

        if (!age) {
            formIsValid = false;
            errors["age"] = "Age is required.";
        } else if (isNaN(age) || age <= 0) {
            formIsValid = false;
            errors["age"] = "Age must be a positive number.";
        }

        if (!college) {
            formIsValid = false;
            errors["college"] = "College is required.";
        }

        if (!email) {
            formIsValid = false;
            errors["email"] = "Email is required.";
        } else if (!/\S+@\S+\.\S+/.test(email)) {
            formIsValid = false;
            errors["email"] = "Email is invalid.";
        }

        if (!userName) {
            formIsValid = false;
            errors["userName"] = "User Name is required.";
        }

        if (!password) {
            formIsValid = false;
            errors["password"] = "Password is required.";
        }

        if (!dateOfBirth) {
            formIsValid = false;
            errors["dateOfBirth"] = "Date of Birth is required.";
        }

        if (!contact) {
            formIsValid = false;
            errors["contact"] = "Contact is required.";
        }

        if (!roles) {
            formIsValid = false;
            errors["roles"] = "Roles is required.";
        }

        if (!addresses) {
            formIsValid = false;
            errors["addresses"] = "Addresses is required.";
        }

        if (!skills) {
            formIsValid = false;
            errors["skills"] = "Skills is required.";
        }

        if (!departmentId) {
            formIsValid = false;
            errors["departmentId"] = "Department is required.";
        }

        this.setState({ validationErrors: errors });
        return formIsValid;
    }

    saveOrUpdateEmployee(event) {
        event.preventDefault(); // Prevent default form submission
        const { id } = this.state;
        if (this.validateForm()) {
            const employeeData = {
                firstName: this.state.firstName,
                lastName: this.state.lastName,
                age: this.state.age,
                college: this.state.college,
                email: this.state.email,
                userName: this.state.userName,
                password: this.state.password,
                dateOfBirth: this.state.dateOfBirth,
                contact: this.state.contact,
                roles: this.state.roles,
                addresses: this.state.addresses,
                skills: this.state.skills,
                departmentId: this.state.departmentId
            };

            if (id) {
                updateEmployee(id, employeeData)
                    .then(response => {
                        console.log("Employee updated successfully:", response.data);
                        this.props.history.push('/employees'); // Navigate to employee list
                    })
                    .catch(error => {
                        console.error("Error updating employee:", error);
                    });
            } else {
                createEmployee(employeeData)
                    .then(response => {
                        console.log("Employee created successfully:", response.data);
                        this.props.history.push('/employees'); // Navigate to employee list
                    })
                    .catch(error => {
                        console.error("Error creating employee:", error);
                    });
            }
        }
    }

    render() {
        const { id } = this.state;
        const pageTitle = id ? 'Update Employee' : 'Add Employee';

        return (
            <div>
                <h1 className="text-center">{pageTitle}</h1>
                <div className="container">
                    <div className="row">
                        <div className="card col-md-6 offset-md-3">
                            <div className="card-body">
                                <form>
                                    <div className="form-group mb-2">
                                        <label className="form-label">First Name:</label>
                                        <input
                                            type="text"
                                            placeholder="Enter first name"
                                            value={this.state.firstName}
                                            name="firstName"
                                            onChange={this.handleInputChange}
                                            className="form-control"
                                        />
                                        <span style={{ color: "red" }}>{this.state.validationErrors["firstName"]}</span>
                                    </div>
                                    <div className="form-group mb-2">
                                        <label className="form-label">Last Name:</label>
                                        <input
                                            type="text"
                                            placeholder="Enter last name"
                                            value={this.state.lastName}
                                            name="lastName"
                                            onChange={this.handleInputChange}
                                            className="form-control"
                                        />
                                        <span style={{ color: "red" }}>{this.state.validationErrors["lastName"]}</span>
                                    </div>
                                    <div className="form-group mb-2">
                                        <label className="form-label">Age:</label>
                                        <input
                                            type="number"
                                            placeholder="Enter age"
                                            value={this.state.age}
                                            name="age"
                                            onChange={this.handleInputChange}
                                            className="form-control"
                                        />
                                        <span style={{ color: "red" }}>{this.state.validationErrors["age"]}</span>
                                    </div>
                                    <div className="form-group mb-2">
                                        <label className="form-label">College:</label>
                                        <input
                                            type="text"
                                            placeholder="Enter college"
                                            value={this.state.college}
                                            name="college"
                                            onChange={this.handleInputChange}
                                            className="form-control"
                                        />
                                        <span style={{ color: "red" }}>{this.state.validationErrors["college"]}</span>
                                    </div>
                                    <div className="form-group mb-2">
                                        <label className="form-label">Email:</label>
                                        <input
                                            type="email"
                                            placeholder="Enter email"
                                            value={this.state.email}
                                            name="email"
                                            onChange={this.handleInputChange}
                                            className="form-control"
                                        />
                                        <span style={{ color: "red" }}>{this.state.validationErrors["email"]}</span>
                                    </div>
                                    <div className="form-group mb-2">
                                        <label className="form-label">User Name:</label>
                                        <input
                                            type="text"
                                            placeholder="Enter user name"
                                            value={this.state.userName}
                                            name="userName"
                                            onChange={this.handleInputChange}
                                            className="form-control"
                                        />
                                        <span style={{ color: "red" }}>{this.state.validationErrors["userName"]}</span>
                                    </div>
                                    <div className="form-group mb-2">
                                        <label className="form-label">Password:</label>
                                        <input
                                            type="password"
                                            placeholder="Enter password"
                                            value={this.state.password}
                                            name="password"
                                            onChange={this.handleInputChange}
                                            className="form-control"
                                        />
                                        <span style={{ color: "red" }}>{this.state.validationErrors["password"]}</span>
                                    </div>
                                    <div className="form-group mb-2">
                                        <label className="form-label">Date of Birth:</label>
                                        <input
                                            type="date"
                                            value={this.state.dateOfBirth}
                                            name="dateOfBirth"
                                            onChange={this.handleInputChange}
                                            className="form-control"
                                        />
                                        <span style={{ color: "red" }}>{this.state.validationErrors["dateOfBirth"]}</span>
                                    </div>
                                    <div className="form-group mb-2">
                                        <label className="form-label">Contact:</label>
                                        <input
                                            type="text"
                                            placeholder="Enter contact number"
                                            value={this.state.contact}
                                            name="contact"
                                            onChange={this.handleInputChange}
                                            className="form-control"
                                        />
                                        <span style={{ color: "red" }}>{this.state.validationErrors["contact"]}</span>
                                    </div>
                                    <div className="form-group mb-2">
                                        <label className="form-label">Roles:</label>
                                        <input
                                            type="text"
                                            placeholder="Enter roles"
                                            value={this.state.roles}
                                            name="roles"
                                            onChange={this.handleInputChange}
                                            className="form-control"
                                        />
                                        <span style={{ color: "red" }}>{this.state.validationErrors["roles"]}</span>
                                    </div>
                                    <div className="form-group mb-2">
                                        <label className="form-label">Addresses:</label>
                                        <input
                                            type="text"
                                            placeholder="Enter addresses"
                                            value={this.state.addresses}
                                            name="addresses"
                                            onChange={this.handleInputChange}
                                            className="form-control"
                                        />
                                        <span style={{ color: "red" }}>{this.state.validationErrors["addresses"]}</span>
                                    </div>
                                    <div className="form-group mb-2">
                                        <label className="form-label">Skills:</label>
                                        <input
                                            type="text"
                                            placeholder="Enter skills"
                                            value={this.state.skills}
                                            name="skills"
                                            onChange={this.handleInputChange}
                                            className="form-control"
                                        />
                                        <span style={{ color: "red" }}>{this.state.validationErrors["skills"]}</span>
                                    </div>
                                    <div className="form-group mb-2">
                                        <label className="form-label">Department Id:</label>
                                        <input
                                            type="text"
                                            placeholder="Enter Department"
                                            value={this.state.departmentId}
                                            name="departmentId"
                                            onChange={this.handleInputChange}
                                            className="form-control"
                                        />
                                        <span style={{ color: "red" }}>{this.state.validationErrors["departmentId"]}</span>
                                    </div>
                                    <button className="btn btn-success" onClick={this.saveOrUpdateEmployee}>Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default EmployeeComponent;
