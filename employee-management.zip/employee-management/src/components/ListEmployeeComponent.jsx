import React, { useState, useEffect } from 'react';
import { listEmployees, deleteEmployee } from '../services/EmployeeService';
import { useNavigate } from 'react-router-dom';

const ListEmployeeComponent = () => {
    const [employees, setEmployees] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        fetchEmployees();
    }, []);

    const fetchEmployees = async () => {
        try {
            const response = await listEmployees(); // Assuming listEmployees returns an object with data property
            setEmployees(response); // Assuming response is an array of employees
        } catch (error) {
            console.error('Error fetching employees:', error);
        }
    };

    const addNewEmployee = () => {
        navigate("/add-employee");
    };

    const updateEmployee = (id) => {
        navigate(`/edit-employee/${id}`);
    };

    const removeEmployee = async (id) => {
        try {
            await deleteEmployee(id);
            // Update employee list after deletion
            fetchEmployees();
        } catch (error) {
            console.error(`Error deleting employee with id ${id}:`, error);
        }
    };

    return (
        <div>
            <h1 className="text-center">List Employee</h1>
            <button className='btn btn-primary mb-2' onClick={addNewEmployee}>Add Employee</button>
            <div>
                <table className="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Age</th>
                            <th>College</th>
                            <th>Email</th>
                            <th>Username</th>
                            <th>Contact</th>
                            <th>Roles</th>
                            <th>Address</th>
                            <th>Skills</th>
                            <th>Reference</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {employees.map((employee, index) => (
                            <tr key={index}>
                                <td>{employee.firstName}</td>
                                <td>{employee.lastName}</td>
                                <td>{employee.age}</td>
                                <td>{employee.college}</td>
                                <td>{employee.email}</td>
                                <td>{employee.userName}</td>
                                <td>{employee.contact}</td>
                                <td>{employee.roles}</td>
                                <td>{employee.addresses}</td>
                                <td>{employee.skills}</td>
                                <td>{employee.reference}</td>
                                <td>
                                    <button className='btn btn-info' onClick={() => updateEmployee(employee.id)}>Update</button>
                                    <button className='btn btn-danger' onClick={() => removeEmployee(employee.id)}>Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default ListEmployeeComponent;
