import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { StorageService } from '../../dashboard/service/storage/storage.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private url = `http://localhost:8080/api/admin`;
  constructor(private http: HttpClient) { }
  
  postCategory(CategoryDto: any) {
    console.log('Request Headers:', this.createAuthorizationHeader());
    return this.http.post<[]>(`${this.url}/category`, CategoryDto, {
      headers: this.createAuthorizationHeader()
    });
  }
  
  //categories
getCategories(){
  return this.http.get(`${this.url}/categories`, 
  {
    headers: this.createAuthorizationHeader()
  })
}

getCategoriesByTitle(title: string) : Observable<any>{
  return this.http.get(`${this.url}/categories/${title}`, {
    headers: this.createAuthorizationHeader(),
  });
}

postProduct(categoryId: number, ProductDto: any) {
  console.log('Request Headers:', this.createAuthorizationHeader());
  return this.http.post<[]>(`${this.url}/${categoryId}/product`, ProductDto, {
    headers: this.createAuthorizationHeader()
  });
}

getCategoriesByCategory(categoryId: number){
  return this.http.get(`${this.url}/${categoryId}/products`, 
  {
    headers: this.createAuthorizationHeader()
  })
}
deleteProductById(ProductId: number){
  return this.http.delete(`${this.url}/product/${ProductId}`)
}
  createAuthorizationHeader():  HttpHeaders{
    let authHeaders: HttpHeaders = new HttpHeaders();
    return authHeaders.set(
      "Authorization", "Bearer" + StorageService.getToken()
    );
  }

  updateProduct(productId: number, ProductDto: any) {
    console.log('Request Headers:', this.createAuthorizationHeader());
    return this.http.put<[]>(`${this.url}/product/${productId}`, ProductDto, {
      headers: this.createAuthorizationHeader()
    });
  }

  getProductsById(ProductId: number){
    return this.http.get(`${this.url}/product/${ProductId}`)
  }
}
