import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../service/admin.service';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-view-products',
  templateUrl: './view-products.component.html',
  styleUrl: './view-products.component.css'
})
export class ViewProductsComponent implements OnInit{
  Products: any[] = [];
  categoryId: number = this.activatedroute.snapshot.params['categoryId']
  productId: number = this.activatedroute.snapshot.params['productId'];
  validateForm!: FormGroup;
  constructor(private adminService: AdminService, private activatedroute: ActivatedRoute, private fb: FormBuilder){

  }
  ngOnInit(): void {
    this.validateForm = this.fb.group({
      title: ['', Validators.required]
    });
    this.getAllProducts();
    console.log("dfghjk", this.Products)
  }
  
  getAllProducts(){
    this.adminService.getCategoriesByCategory(this.categoryId).subscribe((res: any) =>{
      this.Products = res;
      console.log(this.Products);
    })
  }
  submitForm(): void {
  }

  deleteProduct(id: number){
      console.log(id);
      this.adminService.deleteProductById(id).subscribe((res)=>{
        alert("Successfully Deleted");
      })
  }
  onclick(){
    console.log("Clicked")
  }
}
