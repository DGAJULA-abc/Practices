import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin.component';
import { AddCategoryComponent } from './components/add-category/add-category.component';
import { PostProductComponent } from './components/post-product/post-product.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ViewProductsComponent } from './components/view-products/view-products.component';
import { UpdateProductComponent } from './components/update-product/update-product.component';

const routes: Routes = [{ path: '', component: AdminComponent },
{ path: 'addCategory', component: AddCategoryComponent },
{ path: 'dashboard', component: DashboardComponent },
{ path: 'product', component: PostProductComponent },
{ path: ':categoryId/product', component: PostProductComponent },
{ path: ':categoryId/products', component: ViewProductsComponent },
{ path: 'update/:productId', component: UpdateProductComponent },];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
