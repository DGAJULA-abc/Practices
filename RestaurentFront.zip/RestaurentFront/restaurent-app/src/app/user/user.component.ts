import { ChangeDetectorRef, Component } from '@angular/core';
import { StorageService } from '../dashboard/service/storage/storage.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrl: './user.component.css'
})
export class UserComponent {
  isAdminLoggedIn: boolean = StorageService.isAdminLoggedIn();
  isCustomerLoggedIn: boolean = StorageService.isCustomerLoggedIn();

  constructor(private router: Router, private cdr: ChangeDetectorRef) {}

  ngOnInit(): void {
    // Subscribe to router events to check login status on each navigation
    this.router.events.subscribe(event => {
      if (event.constructor.name === 'NavigationEnd') {
        this.isAdminLoggedIn = StorageService.isAdminLoggedIn();
        this.isCustomerLoggedIn = StorageService.isCustomerLoggedIn();
        this.cdr.detectChanges(); // Trigger change detection
      }
    });
  }

  logout(): void {
    StorageService.signOut();
    this.router.navigate(['/login']);
    this.isAdminLoggedIn = false;
    this.isCustomerLoggedIn = false;
    this.cdr.detectChanges(); // Update view after logout
  }
}
