import { Component, ChangeDetectorRef, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StorageService } from './service/storage/storage.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'] // Corrected from styleUrl to styleUrls
})
export class DashboardComponent implements OnInit {
  isAdminLoggedIn: boolean = StorageService.isAdminLoggedIn();
  isCustomerLoggedIn: boolean = StorageService.isCustomerLoggedIn();

  constructor(private router: Router, private cdr: ChangeDetectorRef) {
    console.log("Dinesh Construcrot");
  }

  ngOnInit(): void {
    console.log("Dinesh ininliaze");
    // Subscribe to router events to check login status on each navigation
    this.router.events.subscribe(event => {
      if (event.constructor.name === 'NavigationEnd') {
        this.isAdminLoggedIn = StorageService.isAdminLoggedIn();
        this.isCustomerLoggedIn = StorageService.isCustomerLoggedIn();
        this.cdr.detectChanges(); // Trigger change detection
      }
    });
  }

  logout(): void {
    StorageService.signOut();
    this.router.navigate(['/login']);
    this.isAdminLoggedIn = false;
    this.isCustomerLoggedIn = false;
    this.cdr.detectChanges(); // Update view after logout
  }
}
