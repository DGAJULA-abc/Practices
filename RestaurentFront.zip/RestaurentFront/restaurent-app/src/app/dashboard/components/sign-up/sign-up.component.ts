import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../service/auth.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']  // Corrected the property name
})
export class SignUpComponent implements OnInit {
  zoneForm!: FormGroup;
  userRoles: string[] = ['ADMIN', 'USER', 'STAFF']; 

  constructor(private auth: AuthService, private fb: FormBuilder) {}

  ngOnInit(): void {
    this.zoneForm = this.fb.group({
      name: ["", Validators.required],
      email: ["", [Validators.required, Validators.email]], // Added email validator
      password: ["", [Validators.required, Validators.minLength(6)]],
      checkPassword: ["", [Validators.required, Validators.minLength(6)]],
      phoneNumber: ["", Validators.required],
      address: ["", Validators.required],
      userRole: ["", Validators.required] 
    }, { validators: this.passwordMatchValidator }); // Apply the custom validator here
  }
  passwordMatchValidator(form: FormGroup) {
    const password = form.get('password');
    const confirmPassword = form.get('checkPassword');
    return password && confirmPassword && password.value === confirmPassword.value
      ? null
      : { mismatch: true };
  }

  register() {
    console.log(this.zoneForm.value);
    if (this.zoneForm.valid) {
      // Call auth service to handle registration logic
      this.auth.signUp(this.zoneForm.value).subscribe(response => {
        console.log("Registration successful", response);
      }, error => {
        console.error("Registration failed", error);
      });
    }
  }
}
