import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../service/auth.service';
import { StorageService } from '../../service/storage/storage.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'] // Corrected from styleUrl to styleUrls
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  submitted = false;
  errorMessage: string = '';

  constructor(private fb: FormBuilder, private authService: AuthService, private route: Router) {}

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }
  onSubmit(): void {
    this.submitted = true;
    this.errorMessage = '';
  
    if (this.loginForm.invalid) {
      return;
    }
  
    this.authService.login(this.loginForm.value).subscribe(
      (data) => {
        if (data.userId != null) {
          const user = { id: data.userId, role: data.userRole };
          StorageService.saveToken(data.jwt);
          StorageService.saveUser(user);
  
          if (StorageService.isAdminLoggedIn()) {
            this.route.navigate(['/admin']);
          } else if (StorageService.isCustomerLoggedIn()) {
            this.route.navigate(['/user']);
          } else {
            this.route.navigate(['']);
          }
        } else {
          this.errorMessage = 'Wrong credentials';
        }
      },
      (error) => {
        this.errorMessage = 'Login failed. Please check your credentials.';
      }
    );
  }
  
}
