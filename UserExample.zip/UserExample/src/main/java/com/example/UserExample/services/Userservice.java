package com.example.UserExample.services;

import com.example.UserExample.entity.User;

public interface Userservice{
	User Adduser(User user);
}
