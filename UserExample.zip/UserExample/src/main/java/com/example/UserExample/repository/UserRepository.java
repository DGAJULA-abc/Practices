package com.example.UserExample.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.UserExample.entity.User;

public interface UserRepository extends JpaRepository<User, Integer>{

}
