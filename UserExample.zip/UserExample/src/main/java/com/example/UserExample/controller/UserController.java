package com.example.UserExample.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpServerErrorException;

import com.example.UserExample.entity.User;
import com.example.UserExample.services.Userservice;

@RestController
@RequestMapping("/main/")
public class UserController {

	@Autowired
	private Userservice userservice;
	
	@PostMapping("user")
	public ResponseEntity<?> addUser(@RequestBody User user){
		User user1 =this.userservice.Adduser(user);
		return new ResponseEntity<>("Sucessfully created user"+user1, HttpStatus.CREATED);
	}
	
}
