package com.example.UserExample.exception;

public class RunTimeException extends Exception{

	public RunTimeException(String message) {
		super(message);
	}
	
}
