package com.example.UserExample.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.UserExample.entity.User;
import com.example.UserExample.repository.UserRepository;
import com.example.UserExample.services.Userservice;

@Service
public class UserServiceImpl implements Userservice{

	@Autowired
	private UserRepository userRepository;
	
	@Override
	public User Adduser(User user) {
		// TODO Auto-generated method stub
		return this.userRepository.save(user);
	}


	
}
