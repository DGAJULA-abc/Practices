import { ChangeDetectorRef, Component } from '@angular/core';
import { StorageService } from '../dashboard/service/storage/storage.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrl: './admin.component.css'
})
export class AdminComponent {
  isAdminLoggedIn: boolean = StorageService.isAdminLoggedIn();
  isCustomerLoggedIn: boolean = StorageService.isCustomerLoggedIn();
  constructor(private router: Router, private cdr: ChangeDetectorRef) {}

  ngOnInit(): void {
    // Subscribe to router events to check login status on each navigation
    this.router.events.subscribe(event => {
      if (event.constructor.name === 'NavigationEnd') {
        this.isAdminLoggedIn = StorageService.isAdminLoggedIn();
        this.isCustomerLoggedIn = StorageService.isCustomerLoggedIn();
        this.cdr.detectChanges(); // Trigger change detection
      }
    });
  }

  logout(): void {
    StorageService.signOut();
    this.router.navigate(['/login']);
    this.isAdminLoggedIn = false;
    this.isCustomerLoggedIn = false;
    this.cdr.detectChanges(); // Update view after logout
  }

  isCurrentRoute(route: string): boolean {
    return this.router.url === route;
  }
}
