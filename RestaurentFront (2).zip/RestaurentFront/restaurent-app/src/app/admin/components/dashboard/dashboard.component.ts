import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdminService } from '../../service/admin.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent {
  categoryForm!: FormGroup;
  validateForm!: FormGroup;
  isSpinning: boolean = false;
  data: any[] = [];
  categories: any[] = []; // Correct array to hold categories

  constructor(private fb: FormBuilder, private adminService: AdminService) {}

  ngOnInit(): void {
    this.categoryForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      description: ['', [Validators.required, Validators.maxLength(500)]],
      img: [null, Validators.required]
    });

    this.validateForm = this.fb.group({
      title: ['', Validators.required]
    });

    this.getAllCategories();
  }

  getAllCategories(): void {
    this.adminService.getCategories().subscribe(
      (res: any) => {
        this.data = res;
        this.categories = res;
        console.log('All categories:', this.data);
      },
      (error) => console.error('Error fetching categories:', error)
    );
  }
  submitForm(): void {
    const title = this.validateForm.get('title')?.value.trim();
    if (title) {
     // this.isSpinning = true;
      this.categories = []; // Clear categories before search
      console.log('Filtered categories:', this.categories);
      this.adminService.getCategoriesByTitle(title).subscribe(
        (res: any) => {
          if(res){
            this.categories = res; // Assuming the API returns an array directly
            console.log('Filtered categories:', this.categories);
            this.isSpinning = false; // Hide spinner after success
          }else{
            (error: any) => {
              console.error('Error fetching category by title:', error);
             this.isSpinning = false; // Hide spinner on error
             this.data = res;
            }
          }
        },
      );
    }
  }

}
