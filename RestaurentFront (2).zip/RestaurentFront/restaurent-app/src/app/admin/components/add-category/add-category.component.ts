import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdminService } from '../../service/admin.service';

@Component({
  selector: 'app-add-category',
  templateUrl: './add-category.component.html',
  styleUrls: ['./add-category.component.css']
})
export class AddCategoryComponent implements OnInit {
  categoryForm!: FormGroup;
  selectedImage!: File | null;
  isLoading: boolean = false;
  errorMessage: string | null = null;
  data: any[] = [];
  constructor(private fb: FormBuilder, private adminService: AdminService) {}

  ngOnInit(): void {
    this.categoryForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      description: ['', [Validators.required, Validators.maxLength(500)]],
      img: [null, Validators.required]
    });
    this.getAllCategiries();
  }

  onFileSelect(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.selectedImage = file;
      this.categoryForm.patchValue({ img: file });
    }
  }

  onSubmit(): void {
    if (this.categoryForm.valid) {
      this.isLoading = true;
      this.errorMessage = null;

      // Prepare form data for API call
      const formData = new FormData();
      formData.append('name', this.categoryForm.get('name')?.value);
      formData.append('description', this.categoryForm.get('description')?.value);
      if (this.selectedImage) {
        formData.append('img', this.selectedImage);
      }

      // Call API
      this.adminService.postCategory(formData).subscribe({
        next: (response) => {
          console.log('Category added successfully:', response);
          this.isLoading = false;
          this.categoryForm.reset();
          this.selectedImage = null;
          alert('Category added successfully!');
        },
        error: (error) => {
          console.error('Error adding category:', error);
          this.isLoading = false;
          this.errorMessage = 'An error occurred while adding the category.';
        }
      });
    } else {
      console.error('Form is invalid');
    }
  }
  getAllCategiries(){
    this.adminService.getCategories().subscribe((res: any) =>{
      this.data = res;
      console.log("this.data", this.data);
    })
  }
}
