import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdminService } from '../../service/admin.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.component.html',
  styleUrl: './update-product.component.css'
})
export class UpdateProductComponent {
  categoryId: number = this.activatedroute.snapshot.params['categoryId'];
  productId: number = this.activatedroute.snapshot.params['productId'];
  productForm!: FormGroup;
  selectedImage!: File | null;
  isLoading: boolean = false;
  errorMessage: string | null = null;
  data: any[] = [];
  Products: any[] = [];
  selectedImageError: string | null = null;
  constructor(private fb: FormBuilder, private adminService: AdminService,private activatedroute: ActivatedRoute, private route: Router) {}
  ngOnInit() {
    this.productForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      price: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],
      description: ['', [Validators.required, Validators.maxLength(500)]],
      img: [null, Validators.required]
    });
    this.getAllCategories();
    this.getProductsById();
    console.log(this.Products);
    this.productForm.patchValue(this.Products);
  }
  onFileSelect(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.selectedImage = file;
      this.productForm.patchValue({ img: file });
    }
  }
  onSubmit(){
    console.log(this.productForm.value);
    if (this.productForm.valid) {
      this.isLoading = true;
      this.errorMessage = null;

      // Prepare form data for API call
      const formData = new FormData();
      formData.append('name', this.productForm.get('name')?.value);
      formData.append('price', this.productForm.get('price')?.value);
      formData.append('description', this.productForm.get('description')?.value);
      if (this.selectedImage) {
        formData.append('img', this.selectedImage);
      }

      // Call API
      this.adminService.updateProduct(this.productId,formData).subscribe({
        next: (response) => {
          console.log('Category added successfully:', response);
          this.isLoading = false;
          this.productForm.reset();
          this.selectedImage = null;
          this.route.navigate(['/admin/dashboard'])
        },
        error: (error) => {
          console.error('Error adding category:', error);
          this.isLoading = false;
          //this.errorMessage = 'An error occurred while adding the category.';
          alert('Category added successfully!');
        }
      });
    } else {
      console.error('Form is invalid');
    }
  }
 
  getAllCategories(): void {
    this.adminService.getCategories().subscribe((res: any) => {
      this.data = res;
      console.log("Fetched Categories:", this.data);
      this.productForm.patchValue(this.data);
    });
  }
  getProductsById(){
    this.adminService.getProductsById(this.productId).subscribe((res: any) =>{
      this.Products = res;
      console.log(this.Products);
      this.productForm.patchValue(this.Products);
    })
  }
  submitForm(): void {
  }
}
