import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { StorageService } from '../../dashboard/service/storage/storage.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private url = `http://localhost:8080/api/customer`;
  constructor(private http: HttpClient) { }
  createAuthorizationHeader():  HttpHeaders{
    let authHeaders: HttpHeaders = new HttpHeaders();
    return authHeaders.set(
      "Authorization", "Bearer" + StorageService.getToken()
    );
  }
}
