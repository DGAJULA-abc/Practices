import React, { Component } from "react";

class Example extends Component{

state = {
    name: "",
    email: "",
    city: "",
    password: ""
}

Changedata = (e) =>{
    let val = e.target.value;
    this.setState({name:val});
}

formSubmit = (event) =>{
    event.preventDefault();
    console.log(this.state.name);
}

render(){
    return(
        <div className="App">
            <h1>Hello {this.state.name}</h1>
            <form onSubmit={this.formSubmit}>
                <div className="form-group" style={{marginLeft:200}}>
                    <label>User Name:</label>
                    <input type="text" name="name" onChange={this.Changedata}></input>
                </div>

                <div className="form-group" style={{marginLeft:200}}>
                    <label>Email:</label>
                    <input type="text" name="email" onChange={this.Changedata}></input>
                </div>

                <div className="form-group" style={{marginLeft:200}}>
                    <label>City:</label>
                    <input type="text" name="city" onChange={this.Changedata}></input>
                </div>

                <div className="form-group" style={{marginLeft:200}}>
                    <label>Password</label>
                    <input type="text" name="password" onChange={this.Changedata}></input>
                </div>
                <button type="submit">Submit</button>
            </form>
        </div>
    )
}

}
export default Example