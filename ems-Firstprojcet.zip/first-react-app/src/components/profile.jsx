import React, { Component } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';

export default class Profile extends Component {
    state = {
        title : "",
        body : ""
    }
    fromSubmit = (e) =>{
        e.preventDefault();
        console.log(this.state.title);
        console.log(this.state.body);
        alert("Submited---------");
        axios.post('/user', {
            title:this.state.title,
            body: this.state.body
        })
        .then((response) => {
            this.setState({ posts: response.data });
            console.log(response);
        })
        .catch((error) => {
            console.log(error);
        });
    }
    render() {
        return (
            <center>
                <div>
                    <div className="jumbotron col-lg-4" style={{ backgroundColor: "aqua" }}>
                        <form style={{margin: 15}} onSubmit={this.fromSubmit}>
                            <div className="form-group">
                                <label htmlFor="exampleInputEmail1">Title</label>
                                <input type="text" className="form-control" id="title" name="title" aria-describedby="emailHelp" placeholder="title"  onChange={event=>this.setState({title:event.target.value})}/>
                                {/* <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone else.</small> */}
                            </div>
                            <div className="form-group">
                                <label htmlFor="exampleInputPassword1">Details</label>
                             <textarea className="form-control" id="body" name="body" onChange={event=>this.setState({body:event.target.value})}></textarea>
                            </div>
                            {/* <div className="form-check">
                                <input type="checkbox" className="form-check-input" id="exampleCheck1" />
                                <label className="form-check-label" htmlFor="exampleCheck1">Check me out</label>
                            </div> */}
                            <button type="submit" className="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </center>
        );
    }
}
