import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Employee } from '../employee';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  base_url = `http://localhost:8080/api/employee`;
  
  constructor(private http: HttpClient) { }

  getEmployeeLise(): Observable<Employee[]> {
    return this.http.get<Employee[]>(this.base_url);
  }

  postEmployeeData(employee: any): Observable<Employee[]> {
    return this.http.post<Employee[]>(this.base_url, employee);
  }

  getEmployeeById(id: number): Observable<Employee> {
    return this.http.get<Employee>(`${this.base_url}/${id}`);
  }

  updateEmployee(id: number, employee: any): Observable<Employee[]> {
    return this.http.put<Employee[]>(`${this.base_url}/${id}`, employee);
  }

  deleteEmployee(id: number): Observable<void> {
    return this.http.delete<void>(`${this.base_url}/${id}`);
  }

  completeEmployee(id: number): Observable<Employee> {
    return this.http.patch<Employee>(`${this.base_url}/${id}/complete`, {});
  }

  incompleteEmployee(id: number): Observable<Employee> {
    return this.http.patch<Employee>(`${this.base_url}/${id}/in-complete`, {});
  }
}
