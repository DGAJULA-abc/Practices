import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { EmployeeService } from '../services/employee.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../employee';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css'] // corrected 'styleUrl' to 'styleUrls'
})
export class UpdateEmployeeComponent implements OnInit {
  zoneForm!: FormGroup;
  employee: Employee = new Employee(); // Correctly typed Employee instance
  id!: number; // Ensure id is a number

  constructor(
    private fb: FormBuilder,
    private employeeService: EmployeeService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    this.zoneForm = this.fb.group({
      firstName: '',
      lastName: '',
      emailId: '',
      completed: false
    });

    this.employeeService.getEmployeeById(this.id).subscribe((response: Employee) => {
      this.employee = response;
      console.log("------------", this.employee);
      this.zoneForm.patchValue({
        firstName: this.employee.firstName,
        lastName: this.employee.lastName,
        emailId: this.employee.emailId,
        completed: this.employee.completed
      });
    });
  }

  onsubmit(): void {
    this.employeeService.updateEmployee(this.id, this.zoneForm.value).subscribe(response => {
      console.log('Employee updated successfully', response);
      this.goToListEmployee();
    });
  }

  goToListEmployee(): void {
    this.router.navigate(['/List-Employee']);
  }
}
