import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { EmployeeService } from '../services/employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrl: './add-employee.component.css'
})
export class AddEmployeeComponent implements OnInit{
  zoneForm!: FormGroup;
  employee: any[] = [];
  constructor(private fb: FormBuilder, private auth: EmployeeService, private router: Router){

  }
  ngOnInit(): void {
    this.zoneForm = this.fb.group({
      firstName: '',
      lastName: '',
      emailId: '',
      completed:''
    });
  }
  onsubmit(){
    console.log(this.zoneForm.value);
    this.auth.postEmployeeData(this.zoneForm.value).subscribe((response) =>{
      console.log("Employee Added");
      this.employee = response;
      this.goToListEmployee();
    })
  }
  goToListEmployee(){
    this.router.navigate(['/List-Employee'])
  }
}
