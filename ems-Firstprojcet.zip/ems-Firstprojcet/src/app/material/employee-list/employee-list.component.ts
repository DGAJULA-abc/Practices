import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../services/employee.service';
import { Employee } from '../employee';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrl: './employee-list.component.css'
})
export class EmployeeListComponent implements OnInit{
  employees: Employee[] = [];

  constructor(private auth: EmployeeService, private router: Router) { }

  ngOnInit(): void {
    this.getEmployees();
  }

  getEmployees(): void {
    this.auth.getEmployeeLise().subscribe((response: Employee[]) => {
      this.employees = response;
    });
  }

  updateEmployee(id: number): void {
    console.log(id);
    this.router.navigate(['update-employee', id]);
  }

  deleteEmployee(id: number): void {
    console.log(id);
    this.auth.deleteEmployee(id).subscribe(response => {
      console.log('Successfully deleted', response);
      this.getEmployees();
    });
  }

  completeEmployee(id: number): void {
    this.auth.completeEmployee(id).subscribe(response => {
      console.log(response);
      // Update the employee status in the local array
      this.employees = this.employees.map(employee => 
        employee.id === id ? { ...employee, completed: true } : employee
      );
    });
  }

  incompleteEmployee(id: number): void {
    this.auth.incompleteEmployee(id).subscribe(response => {
      console.log(response);
      // Update the employee status in the local array
      this.employees = this.employees.map(employee => 
        employee.id === id ? { ...employee, completed: false } : employee
      );
    });
  }
  }
