import React from 'react'

function Hello(probs){
    return <h1>Hello Dinesh {probs.name}</h1>;
}

export default Hello