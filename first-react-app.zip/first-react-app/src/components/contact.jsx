import React,{Component} from "react";

export default class contact extends Component{
    state = {
        count: 0
    }
    increase = () =>[
        this.setState({count:this.state.count + 2})
    ]
    render(){
        return(
            <div>
                <h1>This is contact Clicking me {this.state.count}</h1>
                <button onClick={this.increase}></button>
            </div>
        );
    }
}