import React, { Component } from "react";
import axios from "axios";
import { BrowserRouter as Router, Route, Routes, Link, Switch } from 'react-router-dom';
export default class Blog extends Component {
    state = {
        posts: [],
    }

    componentDidMount() {
        axios.get('https://jsonplaceholder.typicode.com/posts')
            .then((response) => {
                this.setState({ posts: response.data });
                console.log(response);
            })
            .catch((error) => {
                console.log(error);
            });
    }

    render() {
        const posts = this.state.posts;
        const allPosts = posts.map((post, idx) => (
            <div key={idx}>
                <a href="">{post.title}</a><br />
                <p>{post.body}</p>
            </div>
        ));

        return (
            <div>
                <Link to="/writepost">Add New</Link>
                <div className="media">
                    <div className="media-body">
                      <h2>Hello Blog</h2>
                      {allPosts}
                    </div>
                </div>
            </div>
        );
    }
}
