import React,{Component} from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import FormControl from 'react-bootstrap/FormControl';
import App from '../App';
import About from './about';
import Contact from './contact';
import Blog from './blog';
import Profile from './profile';
import { BrowserRouter as Router, Route, Routes, Link, Switch, NavLink} from 'react-router-dom';
export default class header extends Component{
    render(){
        return(
            <Router>
            <div>
            <Navbar bg="light" expand="lg">
            <Container>
              <Navbar.Brand><Link to="/">Bootstrap</Link></Navbar.Brand>
              <Navbar.Toggle aria-controls="basic-navbar-nav" />
              <Navbar.Collapse id="basic-navbar-nav">
                <Nav className="me-auto">
                  <Nav.Link><Link to="/about">About Us</Link></Nav.Link>
                  <Nav.Link><Link to="/contact">Contact Us</Link></Nav.Link>
                  <Nav.Link><Link to="/blog">Blog</Link></Nav.Link>
                  <Nav.Link><Link to="/profile">Profile</Link></Nav.Link>
                </Nav>
                <Form className="d-flex">
                  <FormControl type="search" placeholder="Search" className="me-2" />
                  <Button variant="outline-success">Search</Button>
                </Form>
              </Navbar.Collapse>
            </Container>
          </Navbar>
            </div>
            <Routes>
                    <Route path="/about" element={<About />} />
                    <Route path="/contact" element={<Contact />} />
                    <Route path="/blog" element={<Blog />} />
                    <Route path="/profile" element={<Profile />} />
                    <Route path="/" element={<App />} />
                </Routes>
            </Router>
        );
    }
}