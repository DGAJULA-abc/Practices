import React, { Component } from "react";

class Learning extends Component{
    constructor(probs){
        super(probs);
        this.state = {
            fruit : [
                {name:'Mango',weight: '120'},
                {name:'orange',weight: '120'},
                {name:'banana',weight: '120'},
                {name:'Apple',weight: '120'},
            ]
        }
    }
    onClick = () =>{
        console.log("Heloo-------------------");
        alert("Successfully");
        this.setState(
            {
                fruit : [
                    {name:'Samsung',weight: '120'},
                    {name:'orange',weight: '120'},
                    {name:'banana',weight: '120'},
                    {name:'Nokia',weight: '120'},
                ]
            }
        )
    }
    render(){
        return (
            <div>
                <button onClick={this.onClick}>Click me!</button>
                <h1>{this.state.fruit[0].name}</h1>
                <h1>{this.state.fruit[1].name}</h1>
                <h1>{this.state.fruit[2].name}</h1>
                <h1>{this.state.fruit[3].name}</h1>
            </div>
        ) 
    }
}

export default Learning