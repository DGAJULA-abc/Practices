import './App.css';
import Learn from './components/Hello'
import Glow from './components/Learning'
import logo from './logo.svg'
import Check from './components/Check';
import Froms from './components/Froms';
import Example from './components/Example';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useState } from 'react';
function App() {
  const [count, incount] = useState(0);
  return (
    // <div className="App">
    
    // </div>
    <div>
      <h2>Clicking me {count}</h2>
    <button onClick={()=>{incount(count+2)}}> Click me</button>
    </div>
  );
}

export default App;
