package com.example.Limits_service.entity;

@Entity
public class User {
	
}
