package com.microservicesexamples.productServices.service;

import org.springframework.stereotype.Service;

import com.microservicesexamples.productServices.dto.ProductRequest;
import com.microservicesexamples.productServices.model.Product;
import com.microservicesexamples.productServices.repository.ProductRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ProductService {

    private ProductRepository productRepository;

    public void createProduct(ProductRequest productRequest) {
        Product product =new Product();
        product.setName(productRequest.getName());
        product.setPrice(productRequest.getPrice()); // Assuming there's a price field
        product.setDescription(productRequest.getDescription()); // Assuming there's a description
        productRepository.save(product);
    }
}
