package com.microservicesexamples.productServices.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.microservicesexamples.productServices.model.Product;

public interface ProductRepository extends MongoRepository<Product, String> {

}
