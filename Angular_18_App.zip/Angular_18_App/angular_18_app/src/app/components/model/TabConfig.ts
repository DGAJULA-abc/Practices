export interface TabConfig {
  id: number;
  tabName: string;
  tabOrder: number;
  fieldName: string;
  fieldOrder: number;
  fieldGroup: string;
  fieldDataType: string;
  fieldReference: string | null;
  optionTable: string;
  optionName: string;
  optionUser: string;
  optionValue: string | null;
  optionDataDefault: string;
  enabled: boolean;
  modifiesDevOption: string | null;
  optionUiData: string | null;
}
