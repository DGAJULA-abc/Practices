import { Component, OnInit, inject } from '@angular/core';
import { MasterService } from '../services/master.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-designation',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './designation.component.html',
  styleUrl: './designation.component.css'
})
export class DesignationComponent implements OnInit{
  data: any[] = [];
  ngOnInit(): void {
    this.getData();
  }
//  constructor(private auth: MasterService){

//  }
  auth = inject(MasterService);
  getData(){
   this.auth.getAllData().subscribe((datas) =>{
     this.data = datas;
   })
  }
}
