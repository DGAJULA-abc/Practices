import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TabConfig } from '../model/TabConfig';

@Injectable({
  providedIn: 'root'
})
export class MasterService {

  constructor(private http: HttpClient) { }
  url = `http://localhost:3000/posts`;
  getAllData(){
   return this.http.get<TabConfig[]>(this.url)
  }
}
