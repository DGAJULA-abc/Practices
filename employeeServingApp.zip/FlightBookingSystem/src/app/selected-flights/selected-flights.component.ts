import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-selected-flights',
  templateUrl: './selected-flights.component.html',
  styleUrl: './selected-flights.component.css'
})
export class SelectedFlightsComponent {
  zoneForm: FormGroup;

  constructor(private formBuilder: FormBuilder) {
    this.zoneForm = this.formBuilder.group({
      firstName: '',
      lastName: '',
      gender: '',
    });
  }
  submitdata() {
    console.log(this.zoneForm.value);
  }
}
