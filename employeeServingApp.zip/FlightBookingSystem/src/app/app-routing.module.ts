import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SearchFlightComponent } from './search-flight/search-flight.component';
import { NavComponent } from './nav/nav.component';
import { AvailableFlightsComponent } from './available-flights/available-flights.component';
import { SelectedFlightsComponent } from './selected-flights/selected-flights.component';

const routes: Routes = [
  {
    path: '',
    component: LoginComponent,
  },
  {
    path: 'nav',
    component: NavComponent,
  },
  {
    path: 'Search',
    component: SearchFlightComponent,
  },
  {
    path: 'available',
    component: AvailableFlightsComponent,
  },
  {
    path: 'selected',
    component: SelectedFlightsComponent,
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
