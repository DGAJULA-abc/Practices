import { Component, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FlightService } from '../flight.service';
import { Router } from '@angular/router';
import { Flight } from '../model/flight.model';

@Component({
  selector: 'app-search-flight',
  templateUrl: './search-flight.component.html',
  styleUrl: './search-flight.component.css'
})
export class SearchFlightComponent {
  @Output() searchDetails = new EventEmitter<any>();
  zoneForm: FormGroup;
  Flights: any[] = [];
  origin: string = '';
  destination: string = '';
  constructor(private formBuilder: FormBuilder,private flightService: FlightService,private router: Router,) {
    this.zoneForm = this.formBuilder.group({
      origin: '',
      destination: '',
      date: '',
    });
  }
  submitdata() {
    console.log(this.zoneForm.value);
    // this.flightService.postFlight(this.zoneForm.value).subscribe((res: any) =>{
    //   this.Flights = res;
    //   console.log("Flights", this.Flights);
    // })
    // if (this.zoneForm.valid) {
      this.router.navigate(['/available']);
    //   this.searchDetails.emit(this.zoneForm.value); // Emitting search details
    // }
    // this.flightService.getFlight1(this.zoneForm.value).subscribe((result: any) =>{
    //   this.Flights = result;
    //   console.log("result", this.Flights)
    // })
    this.flightService.searchFlights(this.zoneForm.value)
      .subscribe((data: Flight[]) => {
        this.Flights = data;
      });
  }
}
