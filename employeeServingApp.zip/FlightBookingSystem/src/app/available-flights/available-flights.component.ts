import { Component } from '@angular/core';
import { FlightService } from '../flight.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-available-flights',
  templateUrl: './available-flights.component.html',
  styleUrl: './available-flights.component.css'
})
export class AvailableFlightsComponent {
  constructor(
    private flightService: FlightService,
    private router: Router,
    private route: ActivatedRoute
  ){
      
  }
  ngOnInit(): void {
    this.getRowData();
  }
  Flights: any[] = [];
  getRowData() {
    this.flightService.getFlight().subscribe((result: any) =>{
      this.Flights = result;
      console.log("result", this.Flights)
    })
  }
  Book(id:number){
    console.log('Clicked Book for flight ID:', id);
    //this.router.navigate(['/selected'],{ queryParams: { id: id } });
  }
}
