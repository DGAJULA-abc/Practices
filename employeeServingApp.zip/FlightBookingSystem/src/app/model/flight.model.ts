export interface Flight {
id: Number,
flightNumber: string,
origin: string,
destination: string,
date: string,
fare: Number
}