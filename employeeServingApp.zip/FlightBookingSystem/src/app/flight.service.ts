import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Flight } from './model/flight.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FlightService {

  constructor(private http: HttpClient) { }
  baseUrl = 'http://localhost:8080/api/flight' ; 
  getFlight(): any {
    let flights: any = [];
    return this.http.get<Flight>(this.baseUrl,flights);
  }
  getFlight1(flightData: any): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/search`, { params: flightData });
  }
  postFlight(flight: Flight): any{
    let flight1: any = [];
    return this.http.post<Flight>(this.baseUrl, flight);
  }
  searchFlights(flightData: any): Observable<Flight[]> {
    let params = new HttpParams();
    if (flightData.origin) {
      params = params.set('origin', flightData.origin);
    }
    if (flightData.destination) {
      params = params.set('destination', flightData.destination);
    }
    // Add more conditions for other flightData properties if needed

    return this.http.get<Flight[]>(`${this.baseUrl}/search`, { params });
  }
}
