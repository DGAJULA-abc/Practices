import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit{
  zoneForm: FormGroup;

  constructor(private formBuilder: FormBuilder, private router: Router,) {
    this.zoneForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }
  isLoggedIn : boolean = false
  ngOnInit(): void {
    this.zoneForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  submitdata() {
    console.log(this.zoneForm.value);
    this.isLoggedIn = true;
    if(this.zoneForm.valid){
      this.router.navigate(['/Search']);
    }
  }
}
