import { Component, OnInit } from '@angular/core';
import { Router,NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrl: './nav.component.css'
})
export class NavComponent implements OnInit{
  activeLink: string = ''; // Track active link

  constructor(private router: Router) { }

  ngOnInit(): void {
    
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        // Extract the current active link from the router URL
        this.activeLink = event.urlAfterRedirects.split('/')[1];
      }
    });
  }
}
