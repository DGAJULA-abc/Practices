import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css'
})
export class SignupComponent implements OnInit{
    data: any;
  name: any = '';
    weeks: any[] = [
      { id: 1, name: "Sunday" },
      { id: 2, name: "Monday" },
      { id: 3, name: "Tuesday" },
      { id: 4, name: "Wednesday" },
      { id: 5, name: "Thursday" },
      { id: 6, name: "Friday" },
      { id: 7, name: "Saturday" }
    ];
  
    weeksName: any[] = [];
    selectedId: number = 0;
    submitForm1(){
      const matched = this.weeks.find(day => day.id === Number(this.selectedId));
      this.abc = matched ? matched.name : '';
    }
    submitForm() {
      console.log(this.name, "hello");
      this.data = this.name;
      this.getWeekNames();
    }
  
    ngOnInit(): void {
      console.log("weeks", this.weeks);
      this.getWeekNames(); // ✅ Call the function
    }
    abc: any;
    getWeekNames() {
      this.weeksName = []; // Clear previous values
      const matchedDay = this.weeks.find(day => day.id === Number(this.data));
      if (matchedDay) {
        this.weeksName.push(matchedDay.name);
        this.abc = JSON.stringify(matchedDay.name);
      }
      return this.weeksName; // ✅ Optional: return value for logging
    }
  
}
