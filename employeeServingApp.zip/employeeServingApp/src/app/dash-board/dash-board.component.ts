import { Component } from '@angular/core';

@Component({
  selector: 'app-dash-board',
  templateUrl: './dash-board.component.html',
  styleUrl: './dash-board.component.css'
})
export class DashBoardComponent {
  username = 'JohnDoe';
  email = 'john@example.com';
  bio = 'Hello! I love Angular.';
  profileImage: string | ArrayBuffer | null = null;
  defaultImage = 'https://via.placeholder.com/150';
  
  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = e => this.profileImage = reader.result;
      reader.readAsDataURL(file);
    }
  }
  
  saveProfile() {
    // Save logic here (e.g., send to backend)
    console.log('Profile saved:', {
      username: this.username,
      email: this.email,
      bio: this.bio,
      profileImage: this.profileImage
    });
  }
}
