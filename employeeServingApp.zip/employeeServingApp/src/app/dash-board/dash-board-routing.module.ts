import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashBoardComponent } from './dash-board.component';
import { LoginappComponent } from '../login/components/loginapp/loginapp.component';
import { SignupComponent } from '../login/components/signup/signup.component';

const routes: Routes = [{ path: '', component: DashBoardComponent },
{path: 'login', component: LoginappComponent},
{path: 'signUp', component: SignupComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashBoardRoutingModule { }
