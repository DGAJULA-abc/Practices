import React from 'react'
import { NavLink } from 'react-router-dom'
import { isUserLoggedIn, logout } from '../services/AuthService'

const HeaderComponent = () => {
  const isAuth = isUserLoggedIn();
  function logouts(){
    logout();
  }
  return (
    <div>
      <header>
        <nav className="navbar navbar-dark bg-dark navbar-expand-lg">
          <NavLink className="navbar-brand" to="/">Todo Management</NavLink>
          <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav mr-auto">
              {
                isAuth &&  <li className="nav-item">
                <NavLink to="/todos" className="nav-link">Todo</NavLink>
              </li>
              }
            </ul>
          </div>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav mr-auto">
              {
                !isAuth &&   <li className="nav-item">
                <NavLink to="/register" className="nav-link">Register</NavLink>
              </li>
              }
              {
                !isAuth &&  <li className="nav-item">
                <NavLink to="/login" className="nav-link">Login</NavLink>
              </li>
              }
               {
                isAuth &&  <li className="nav-item">
                <NavLink to="/login" onClick={logouts()} className="nav-link">Log Out</NavLink>
              </li>
              }
            </ul>
          </div>
        </nav>
      </header>
    </div>
  )
}

export default HeaderComponent
