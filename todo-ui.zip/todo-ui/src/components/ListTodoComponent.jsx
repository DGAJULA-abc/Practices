import React, { useEffect, useState } from 'react';
import { deleteTodo, getAllTodos, completeTodo, inCompleteTodo} from '../services/TodoService';
import { useNavigate} from 'react-router-dom';
const ListTodoComponent = () => {
    const [todos, setTodos] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        listTodos();
    }, []);

    function listTodos() {
        getAllTodos()
            .then((response) => {
                setTodos(response.data);
            })
            .catch((error) => {
                console.error('Error fetching todos:', error);
            });
    }

    function addNewTodo() {
        navigate('/add-todo');
    }
    function updateTodo(id){
        navigate(`/update-todo/${id}`);
        console.log(id)
    }
    function removeTodo(id){
        console.log(id)
        deleteTodo(id).then((response) =>{
            console.log("successfully delete",response);
            listTodos();
            navigate(`/todos`);
        })
    }
    function completedTodo(id){
        completeTodo(id).then((response)=>{
            listTodos();
        }).catch(error=>{
            console.log(error);
        })
    }

    function incompletedTodo(id){
        inCompleteTodo(id).then((response) =>{
            console.log(response);
            listTodos();   
        }).catch(error =>{
            console.error(error);
        })
    }
    return (
        <div>
            <div className='container'>
                <button className='btn btn-success m-2' onClick={addNewTodo}>
                    Add New Todo
                </button>
                <table className='table table-striped table-bordered'>
                    <thead>
                        <tr>
                            <th>Todo Id</th>
                            <th>Todo Title</th>
                            <th>Todo Description</th>
                            <th>Todo Completed</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {todos.map((todo) => (
                            <tr key={todo.id}>
                                <td>{todo.id}</td>
                                <td>{todo.title}</td>
                                <td>{todo.description}</td>
                                <td>{todo.completed ? 'Yes' : 'No'}</td>
                                <td>
                                    <button className='btn btn-success' onClick={() => updateTodo(todo.id)}>Update</button>
                                    <button className='btn btn-danger' onClick={() => removeTodo(todo.id)}>Delete</button>
                                    <button className='btn btn-danger' onClick={() => completedTodo(todo.id)}>Complete</button>
                                    <button className='btn btn-danger' onClick={() => incompletedTodo(todo.id)}>InComplete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default ListTodoComponent;
