import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [{ path: 'nav', loadChildren: () => import('./navbar/navbar.module').then(m => m.NavbarModule) }, 
{ path: 'admin', loadChildren: () => import('./dash-board/dash-board.module').then(m => m.DashBoardModule) },
{ path: '', redirectTo: 'nav', pathMatch: 'full' },
{ path: 'admin', loadChildren: () => import('./sign-up/sign-up.module').then(m => m.SignUpModule) }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
