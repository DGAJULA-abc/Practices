import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NavbarRoutingModule } from './navbar-routing.module';
import { NavbarComponent } from './navbar.component';
import { SidenavComponent } from './sidenav/sidenav.component';
import { MatButtonModule } from '@angular/material/button';
import { MatBadgeModule } from '@angular/material/badge';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatTabsModule } from '@angular/material/tabs';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { NavtabComponent } from './navtab/navtab.component';
import { ToolbarComponent } from './toolbar/toolbar.component';
import { DashBoardModule } from '../dash-board/dash-board.module';

@NgModule({
  declarations: [
    NavbarComponent,
    SidenavComponent,
    NavtabComponent,
    ToolbarComponent
  ],
  imports: [
    CommonModule,
    NavbarRoutingModule,
    MatButtonModule,
    MatButtonModule,
    MatBadgeModule,
    MatSidenavModule,
    MatToolbarModule,
    MatTabsModule,
    MatListModule,
    MatIconModule,
    DashBoardModule,
  ],
  exports: [ NavbarComponent, ToolbarComponent, SidenavComponent, NavtabComponent]
})
export class NavbarModule { }
