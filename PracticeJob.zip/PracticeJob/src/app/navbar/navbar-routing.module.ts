import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NavbarComponent } from './navbar.component';
import { DashBoardComponent } from '../dash-board/dash-board.component';
import { SignUpComponent } from '../sign-up/sign-up.component';
import { LoginComponent } from '../sign-up/componets/login/login.component';

const routes: Routes = [{ path: '', component: NavbarComponent },
{ path: 'admin/home' , component: DashBoardComponent},
{ path: 'admin/signUp' , component: SignUpComponent},
{ path: 'admin/login' , component: LoginComponent}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class NavbarRoutingModule { }
