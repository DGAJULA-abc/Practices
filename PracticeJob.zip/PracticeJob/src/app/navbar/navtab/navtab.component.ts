import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-navtab',
  templateUrl: './navtab.component.html',
  styleUrl: './navtab.component.css'
})
export class NavtabComponent implements OnInit{

weeks : any[] = [
  {id: '1', week: 'Sunday' },
  {id: '2', week: 'Monday' },
  {id: '3', week: 'Tuesday' },
  {id: '4', week: 'wednesday' },
  {id: '5', week: 'Thursday' },
  {id: '6', week: 'Friday' },
  {id: '7', week: 'Saturday' },
];
@Input() data = this.weeks;
submitWeeks(event: any) {
  const selectedWeek = event.target.value;
  console.log('Selected week:', selectedWeek);
}

weekdaysall: any[] = [];
ngOnInit() {
  this.getbyWeekIds();
  console.log(this.weekdaysall);
}
getbyWeekIds(){
   this.weeks.forEach((ele: any) =>{
    this.weekdaysall.push(ele.week);
   })
}
onsectWeek(event: any){
  const hell0 = event.target.value;
 console.log(hell0);
}
}
