import { Component } from '@angular/core';
import { SampleService } from '../sample.service';

@Component({
  selector: 'app-sample-table',
  templateUrl: './sample-table.component.html',
  styleUrl: './sample-table.component.css'
})
export class SampleTableComponent {
  events: any[]= [];
  constructor(private dataService: SampleService) {}
  ngOnInit(){
    this.getData();
  }
  getData(){
    // this.dataService.getEvents().subscribe(
    //   (data: any) => {
    //     this.events = data;
    //   },
    // );
    this.dataService.getEvents().subscribe((data: any) => {
      this.events = data;
      console.log('breaktype', data);
    });
  }
}
