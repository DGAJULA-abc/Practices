export interface SampleData {
    eventDateTime: string;
    venue: string;
    advisor: string;
    eventSummary: {
      availableCapacity: number;
      checkedIn: number;
      cancelled: number;
      totalReservations: number;
      waitList: number;
      disqualified: number;
    };
    action: string;
  }