import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidatorFn, Validators } from '@angular/forms';

@Component({
  selector: 'app-sample-form',
  templateUrl: './sample-form.component.html',
  styleUrl: './sample-form.component.css'
})
export class SampleFormComponent implements OnInit {
  zoneForm!: FormGroup;
  constructor(private fb: FormBuilder){

  }
  ngOnInit(): void {
    this.zoneForm = this.fb.group({
      name : '',
      email : '',
      age: ['', [Validators.required, positiveNumberValidator()]] // Apply the positiveNumberValidator

    })
  }
  showAgeError: boolean = false
  submitdata(){
 console.log(this.zoneForm.value);
  }
}
  function positiveNumberValidator(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      const valid = control.value > 0;
      return valid ? null : { 'positiveNumber': { value: control.value } };
    };
  }

