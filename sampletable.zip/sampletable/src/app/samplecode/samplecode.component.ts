import { Component } from '@angular/core';
import { SampleService } from '../sample.service';

@Component({
  selector: 'app-samplecode',
  templateUrl: './samplecode.component.html',
  styleUrl: './samplecode.component.css'
})
export class SamplecodeComponent {
  events: any[]= [];
  constructor(private dataService: SampleService) {}
  ngOnInit(){
    this.getData();
  }
  getData(){
    // this.dataService.getEvents().subscribe(
    //   (data: any) => {
    //     this.events = data;
    //   },
    // );
    this.dataService.getEvents().subscribe((data: any) => {
      this.events = data;
      console.log('breaktype', data);
    });
  }

}
