import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SamplecodeComponent } from './samplecode.component';

describe('SamplecodeComponent', () => {
  let component: SamplecodeComponent;
  let fixture: ComponentFixture<SamplecodeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SamplecodeComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SamplecodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
